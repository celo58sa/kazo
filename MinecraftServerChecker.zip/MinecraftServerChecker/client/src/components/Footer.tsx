export function Footer() {
  return (
    <footer className="text-center mt-8 text-xs text-[#EEEEEE] opacity-50">
      <p>Minecraft Bot Controller | Not affiliated with Mojang or Microsoft</p>
    </footer>
  );
}
